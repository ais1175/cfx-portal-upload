fx_version "cerulean"

lua54 "yes"
use_experimental_fxv2_oal "yes"

game "gta5"

name "Test"
author "Test"
version "1.0.0"
